package com.qy.demo.hello.controller;

import org.springframework.web.bind.annotation.*;

@RestController
public class GoodsController {

    @RequestMapping("/")
    public String home(){
        System.out.println("欢迎访问 hello 微服务");
        return "Welcome , this is version 1.0";
    }
}
